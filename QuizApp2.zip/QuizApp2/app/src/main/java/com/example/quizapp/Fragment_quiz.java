package com.example.quizapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment_quiz#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment_quiz extends Fragment {
    private String json;
    int count = 0;
    private static int i = -1;
    private TextView textViewTimer;
    private CountDownTimer countDownTimer;
    private final String selected_option = "selected";
    RadioGroup rgp;
    RadioButton A, B, C, D;
    TextView ques;
    SharedPreferences sharedPref;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Fragment_quiz() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment_quiz.
     */
    // TODO: Rename and change types and number of parameters
    public static Fragment_quiz newInstance(String param1, String param2) {
        Fragment_quiz fragment = new Fragment_quiz();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_quiz, container, false);
        clr();
        textViewTimer = v.findViewById(R.id.time);
        timer();
        ques = v.findViewById(R.id.textView_question);
        rgp = v.findViewById(R.id.Options);
        A = v.findViewById(R.id.option_A);
        B = v.findViewById(R.id.option_B);
        C = v.findViewById(R.id.option_C);
        D = v.findViewById(R.id.option_D);
        loadjson(0);
        i++;
        // Inflate the layout for this fragment
        Button prev = v.findViewById(R.id.btn_prev);
        Button next = v.findViewById(R.id.btn_next);
        Button submit = v.findViewById(R.id.btn_submit);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                    if (i < 9) {
                        i++;
                        loadjson(i);
                        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                savepreference(i);

                            }
                        });

                    } else {
                        i = 9;
                        loadjson(i);
                        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                savepreference(i);

                            }
                        });
                    }
                } catch (Exception e) {
                    Log.e("Tag", "LOAD ERROR" + e);
                }

            }

        });

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (i > 0) {
                        i--;
                        loadjson(i);
                        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                savepreference(i);

                            }
                        });
                    } else {
                        i = 0;
                        loadjson(i);
                        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                savepreference(i);

                            }
                        });
                    }

                } catch (Exception e) {
                    Log.e("Tag", "LOAD ERROR" + e);
                }


            }

        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(requireContext(), ResultValue.class);
//                i.putExtra("count", "" + countcorrect());
                startActivity(i);
//                A.setText(""+countcorrect());

            }
        });
        return v;
    }

    private void loadjson(int i) {
        try {
            Context c = requireContext();
            InputStream ins = c.getAssets().open("questions.json");
            int size = ins.available();
            byte[] buffer = new byte[size];
            ins.read(buffer);
            ins.close();
            json = new String(buffer);
            JSONObject obj = new JSONObject(json);
            JSONArray questions = obj.getJSONArray("questions");
            int max = questions.length();
            JSONObject obj2 = questions.getJSONObject(i);
            ques.setText(i + 1 + ". " + obj2.getString("question"));
            JSONArray opt = obj2.getJSONArray("options");
//            rgp.clearCheck();
            rgp.check(loadpreference(i));
            A.setText(opt.getString(0));
            B.setText(opt.getString(1));
            C.setText(opt.getString(2));
            D.setText(opt.getString(3));
        } catch (Exception e) {
        }

    }

    public void savepreference(int Q) {
        int id = rgp.getCheckedRadioButtonId();
        sharedPref = requireContext().getSharedPreferences(selected_option, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("" + Q, id);
        editor.commit();


    }

    public int loadpreference(int Q) {
        int id = -1;
        sharedPref = requireContext().getSharedPreferences(selected_option, Context.MODE_PRIVATE);
        id = sharedPref.getInt("" + Q, -1);
        return id;

    }

    public void clr() {
        sharedPref = requireContext().getSharedPreferences(selected_option, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear();
        editor.commit();
    }

    //    public int countcorrect() {
//        JSONArray questions = null;
////        Map<String, ?> val;
//        int keys[]=new int[10];
//        String s[] = new String[10], s2[] = new String[10];
//        int id1 = 0;
//        try {
//            InputStream ins = requireContext().getAssets().open("questions.json");
//            int size = ins.available();
//            byte[] buffer = new byte[size];
//            ins.read(buffer);
//            ins.close();
//            json = new String(buffer);
//            JSONObject obj = new JSONObject(json);
//            questions = obj.getJSONArray("questions");
//            int max = questions.length();
//            for (int j = 0; j < max; j++) {
//                JSONObject obj2 = questions.getJSONObject(j);
//                s2[j] = obj2.getString("answer");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        sharedPref = requireContext().getSharedPreferences(selected_option, Context.MODE_PRIVATE);
////        keys[] = sharedPref.getInt();
//        for(int i=0;i<10;i++){
//            keys[i]= sharedPref.getInt(""+i,-1);
//        }
////        int siz = val.size();
//        for (int x = 0; x < keys.length; x++) {
//            int A_opt = A.getId(), B_opt = B.getId(), C_opt = C.getId(), D_opt = D.getId();
//            if (id1 == A_opt) {
//                s[i] = A.getText().toString();
//            }
//            if (id1 == B_opt) {
//                s[i] = B.getText().toString();
//            }
//            if (id1 == C_opt) {
//                s[i] = C.getText().toString();
//            }
//            if (id1 == D_opt) {
//                s[i] = D.getText().toString();
//            }
//            s[i]="";
//        }
//
//
//        for (int i = 0; i < s2.length; i++) {
//            if (s[i].equalsIgnoreCase(s2[i])) {
//                count++;
//            }
//
//        }
//
//
//        return count;
//    }
    public void timer() {


        // Adjust the timer duration as needed (here it's set to 10 seconds)
        long timerDuration = 600000; // 10 seconds in milliseconds

        countDownTimer = new CountDownTimer(timerDuration, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long secondsLeft = millisUntilFinished / 1000;

                textViewTimer.setText("  "+ secondsLeft+"");
            }

            @Override
            public void onFinish() {
//                textViewTimer.setText("Countdown Finished!");
                // Handle what happens when the timer finishes (e.g., show a message)
            }
        };

        countDownTimer.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        countDownTimer.cancel(); // Cancel the timer to avoid memory leaks
    }
}


